/**
 * TaxEntryProcessor.scala
 *
 * Copyright 2019 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 * Submission author
 * UBIT: djjeong
 * Person#: 50270181
 *
 * Collaborators (include UBIT name of each, comma separated):
 * UBIT:
 */
package cse250.pa0.objects

import java.io.File
import java.io.FileWriter
import java.io.BufferedWriter
import cse250.assignments.objects.TaxEntry
import scala.collection.mutable.ArrayBuffer

object TaxEntryProcessor {
  def sanitizeData(filename: String): Unit = {
    // For opening files, look at Scala Cookbook File I/O Excerpt
    val inputFile = scala.io.Source.fromFile(filename)
    // Note: lines is an iterator to the file. This is only valid as long as the file is open.
    //       Ensure you do not close the file prior to finishing the file usage.
    val lines = inputFile.getLines()


    var arrayOfArrays: ArrayBuffer[ArrayBuffer[String]] = ArrayBuffer()

    for (line <- lines) {
      arrayOfArrays.addOne(makeArray(line))
    }



    /* Prototype of the function makeArray down below
    var arrayOfArrays: ArrayBuffer[ArrayBuffer[String]] = new ArrayBuffer()
    var indice1: Int = 0
    var first: Int = 0

    for (line <- lines) {
      var array1: ArrayBuffer[String] = ArrayBuffer()
      for (i <- line.indices) {
        if (line(i).toString == "\"") {
          first += 1
        }
        if (line(i).toString == "," && first % 2 == 0) {
          array1.addOne(line.slice(indice1, i))
          indice1 = i + 1
        }
        if (i == line.length - 1 && first % 2 == 0) {
          array1.addOne(line.slice(indice1, i + 1))
        }
      }
      arrayOfArrays.addOne(array1)
    }
     */

    for (i <- arrayOfArrays) {
      i.remove(0, 2)
      i.remove(5, 7)
      i.remove(11, 3)
      i.remove(12)
      i.remove(18, 3)
      i.remove(23, 3)
    }

    val outputFile = new BufferedWriter(new FileWriter( new File(filename + "-updated")))
    // Without the '\n' character, all output will be written as one long line.
    // Process the lines.

    for (array <- arrayOfArrays) {
      if (array(10) != "") {
        var lineString: String = ""
        for (elem <- array.indices) {
          if (elem != array.length - 1) {
            lineString += array(elem) + ","
          }
          else {
            lineString += array(elem)
          }
        }
        outputFile.write(lineString + "\n")
      }
    }

    // Close the files at the end.
    inputFile.close()
    outputFile.close()
  }

  def computeMostExpensiveEntry(filename: String): TaxEntry = {

    val inputFile = scala.io.Source.fromFile(filename)
    val lines = inputFile.getLines()
    var arrayOfArrays: ArrayBuffer[ArrayBuffer[String]] = ArrayBuffer()

    for (line <- lines) {
      arrayOfArrays.addOne(makeArray(line))
    }

    var valueIndice: Int = findIndex("TOTAL VALUE", arrayOfArrays)
    var greatestValue: Int = 0
    var greatestValueArray: ArrayBuffer[String] = ArrayBuffer()

    for (array <- arrayOfArrays) {
      if (array != arrayOfArrays(0) && array(valueIndice) != "" && array(valueIndice).toInt > greatestValue) {
        greatestValue = array(valueIndice).toInt
        greatestValueArray = array
      }
    }

    inputFile.close()

    var hashMap = new TaxEntry {
      for (i <- arrayOfArrays(0).indices) {
        infoMap += (arrayOfArrays(0)(i) -> greatestValueArray(i))
      }

    }

    hashMap
  }

  def computeOldestEntry(filename: String): TaxEntry = {
    val inputFile = scala.io.Source.fromFile(filename)
    val lines = inputFile.getLines()
    var arrayOfArrays: ArrayBuffer[ArrayBuffer[String]] = ArrayBuffer()

    for (line <- lines) {
      arrayOfArrays.addOne(makeArray(line))
    }

    var oldestIndice: Int = findIndex("YEAR BUILT", arrayOfArrays)
    var oldestYear: Int = 2020
    var oldestYearArray: ArrayBuffer[String] = ArrayBuffer()

    for (array <- arrayOfArrays) {
      if (array != arrayOfArrays(0) && array(oldestIndice) != "" && array(oldestIndice).toInt < oldestYear && array(oldestIndice).toInt > 1000) {
        oldestYear = array(oldestIndice).toInt
        oldestYearArray = array
      }
    }

    inputFile.close()

    var hashMap = new TaxEntry {
      for (i <- arrayOfArrays(0).indices) {
        infoMap += (arrayOfArrays(0)(i) -> oldestYearArray(i))
      }

    }

    hashMap
  }

  def makeArray(string: String): ArrayBuffer[String] = {
    var indice1: Int = 0
    var first: Int = 0

    var array1: ArrayBuffer[String] = ArrayBuffer()
    for (i <- string.indices) {
      if (string(i).toString == "\"") {
        first += 1
      }
      if (string(i).toString == "," && first % 2 == 0) {
        array1.addOne(string.slice(indice1, i))
        indice1 = i + 1
      }
      if (i == string.length - 1 && first % 2 == 0) {
        array1.addOne(string.slice(indice1, i + 1))
      }
    }
    array1
  }

  def findIndex(string: String, arrayofArrays: ArrayBuffer[ArrayBuffer[String]]): Int = {
    var valueIndex: Int = 0

    for (array <- arrayofArrays) {
      for (elem <- array) {
        if (array == arrayofArrays(0) && elem == string) {
          valueIndex = array.indexOf(elem)
        }
      }
    }
    valueIndex
  }
}
