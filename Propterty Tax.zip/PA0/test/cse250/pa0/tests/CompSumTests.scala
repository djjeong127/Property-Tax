/**
 * CompSumTests.scala
 *
 * Copyright 2019 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 * Submission author
 * UBIT: djjeong
 * Person#: 50270181
 *
 * Collaborators (include UBIT name of each, comma separated):
 * UBIT:
 */
package cse250.pa0.tests

import cse250.pa0.objects.Functions
import org.scalatest.FlatSpec

class CompSumTests extends FlatSpec {

  behavior of "FunctionsTest.compSum"

  it should "be sigma notation" in {
    var bool1: Boolean = false
    var bool2: Boolean = true

    def sigma(x: Int ): Long = {
      var num: Long = 0
      for (i <- 1 to x) {
        num += i
      }
      num
    }

    for (i <- 1 to 50000) {
      if (Functions.compSum(i) == sigma(i)) {
        bool1 = true
      }
      else {
        bool2 = false
      }
    }


    assert(bool1 == true && bool2 == true)
  }
}
