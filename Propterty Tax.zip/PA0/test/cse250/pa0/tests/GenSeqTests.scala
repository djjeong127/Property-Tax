/**
 * GenSeqTests.scala
 *
 * Copyright 2019 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 * Submission author
 * UBIT: djjeong
 * Person#: 50270181
 *
 * Collaborators (include UBIT name of each, comma separated):
 * UBIT:
 */
package cse250.pa0.tests

import cse250.pa0.objects.Functions
import org.scalatest.FlatSpec

class GenSeqTests extends FlatSpec {

  behavior of "FunctionsTest.genSeq"

  it should "be even" in {
    var bool1: Boolean = false
    var bool2: Boolean = true

    for (i <- 0 to 1000) {
      for (j <- Functions.genSeq(i)) {
        if (j % 2 == 0 && Functions.genSeq(i).length == i) {
          bool1 = true
        }
        if (j % 2 != 0 || Functions.genSeq(i).length != i) {
          bool2 = false
        }

      }
    }

    assert(bool1 == true && bool2 == true)
  }
}
