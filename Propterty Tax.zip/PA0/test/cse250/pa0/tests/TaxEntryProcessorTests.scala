package cse250.pa0.tests

import cse250.pa0.objects.TaxEntryProcessor
import org.scalatest.FlatSpec

class TaxEntryProcessorTests extends FlatSpec {

}
